import{_ as o,o as t,c,be as r}from"./DmMZDygI.js";const s={};function n(e,l){return t(),c("blockquote",null,[r(e.$slots,"default")])}const _=o(s,[["render",n]]);export{_ as default};
