import{_ as o,o as r,c as s,be as t}from"./DmMZDygI.js";const c={};function n(e,l){return r(),s("ul",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
