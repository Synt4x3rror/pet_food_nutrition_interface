import{aV as n,m as e}from"./DmMZDygI.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
